console.log("Hi! user");
console.log("This is - \"Attendance Application with printing PDF\"");
console.log("Programming by \'Er. vineet k. gupta(B.tech)\'");
console.log("Email - vineetkrishnagupta@gmail.com");
console.log("Phone +91 63945-12899 , +91 98397-60815");
/*

 * MAKE BY Er. Vineet K. gupta(B.tech)
 * Email - vineetkrishnagupta@gamil.com.
 * Phone - +91 63945-12899, +91 98397-60815.

 */