function myPrint(){
    myCls();
    document.getElementById("myInput").style.display = "none";
    document.getElementById("clsDiv").style.display = "none";
    window.print();
    document.getElementById("myInput").style.display = "";
    document.getElementById("clsDiv").style.display = "";
}
/*

 * MAKE BY Er. Vineet K. gupta(B.tech)
 * Email - vineetkrishnagupta@gamil.com.
 * Phone - +91 63945-12899, +91 98397-60815.

 */