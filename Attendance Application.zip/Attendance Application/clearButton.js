function myCls(){
    document.getElementById("myInput").value = "";
    myFunction();
    console.log("HI vineet");
}
/*

 * MAKE BY Er. Vineet K. gupta(B.tech)
 * Email - vineetkrishnagupta@gamil.com.
 * Phone - +91 63945-12899, +91 98397-60815.

 */